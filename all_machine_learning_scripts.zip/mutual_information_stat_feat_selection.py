import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_classif
df = pd.read_csv('1000_1000_iso_res_sus_14797_mut_prof_for_ml.csv',sep=',',low_memory=False)
df.head()
X = dataset.iloc[:,1 :-1]
y = dataset.iloc[:, -1]

mutual_info=mutual_info_classif(X,y)
print(mutual_info)
mutual_info= pd.Series(mutual_info)
mutual_info.index=X.columns
mutual_info.sort_values(ascending=False).plot.bar(figsize=(15,5))
imp_feat=mutual_info.sort_values(ascending=False)
print(imp_feat)
df1=df.drop(df.columns[df.apply(lambda col: col.isnull().sum() > 0)], axis=1)
print(df1)
df1.to_csv("1000_1000_iso_res_sus_"+str(len(imp_feat))+"_mut_prof_for_ml.csv")
