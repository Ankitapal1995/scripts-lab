#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  5 10:10:05 2021

@author: ankita
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sn
dataset = pd.read_csv('ethambu_120_res_for_correlation_matrix.csv',sep=',',low_memory=False)
data=dataset.T
sum_row=data.sum(axis=1) #frequency of features in all the genomes
sum1=data.sum(axis=0) #no. of features present each genom
ls=[]
total=0
for i in range(0,len(sum_row)):
    total=total+sum_row[i]
    ls.append(total)
print(ls)
total=ls[len(ls)-1]
feat_freq=[]
for i in range(0,len(sum_row)):
    g=sum_row[i]/total
    h=g.round(6)
    feat_freq.append(h)
print(len(sum_row))
print(len(feat_freq))
data["sum"]=sum_row
data["frequency"]=feat_freq

freq_cut_off=0/total
print(freq_cut_off)

data1=data[data.frequency>freq_cut_off]
data2=data1.drop(['sum'], axis = 1)
data3=data2.drop(['frequency'], axis = 1)
data4=data3.T
corre_matrix=data4.corr(method='pearson', min_periods=1)

upper_tri = corre_matrix.where(np.triu(np.ones(corre_matrix.shape),k=1).astype(np.bool))
print(upper_tri)
to_drop = [column for column in upper_tri.columns if any(upper_tri[column] > 0.99)]
print(); print(len(to_drop))
f_data=data4.drop(columns=to_drop)

f_col=open("mutations_for_iso_resistant.csv","w")
for col in f_data.columns:
    f_col.write(col)
    f_col.write("\n")
f_col.close()

#del data4[to_drop]
#print(); print(df1.head())
#sn.heatmap(corre_matrix, annot=True)
#plt.show()

f = plt.figure(figsize=(19, 15))
plt.matshow(corre_matrix, fignum=f.number)
plt.xticks(range(corre_matrix.select_dtypes(['number']).shape[1]), corre_matrix.select_dtypes(['number']).columns, fontsize=14, rotation=45)
plt.yticks(range(corre_matrix.select_dtypes(['number']).shape[1]), corre_matrix.select_dtypes(['number']).columns, fontsize=14)
cb = plt.colorbar()
cb.ax.tick_params(labelsize=14)
plt.title('Correlation Matrix', fontsize=16);


f, ax = plt.subplots(figsize=(10, 8))
corr = corre_matrix
sn.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sn.diverging_palette(220, 10, as_cmap=True),
            square=True, ax=ax)


