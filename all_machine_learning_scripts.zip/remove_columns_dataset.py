#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 17:29:12 2020

@author: ankita
"""

import pandas as pd
import numpy as np
data=pd.read_csv("/home/ankita/Desktop/working_file/dir_17_06_2020_ml/600_only_values.csv" ,sep =",",low_memory=False)
df=data.iloc[:, :-1]
df=df.apply(pd.to_numeric)
df1=df.astype(bool).sum(axis=0)
df2=df.astype(bool).sum(axis=1)
df3=df.loc[(df2 !=0),(df1 !=2)]
df3.to_csv("updated"+'600_only_values.csv')