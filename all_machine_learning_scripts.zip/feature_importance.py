# load libraries
from sklearn import datasets
from sklearn import metrics
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier, plot_importance
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy import loadtxt
from numpy import sort
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectFromModel
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score

dataset = pd.read_csv('1000_1000_iso_res_sus_iso_genes_only_for_ml.csv',sep=",",low_memory=False,dtype="int8")
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values
# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.1, random_state = 0)


# fit a ensemble.AdaBoostClassifier() model to the data
model = XGBClassifier(learning_rate =0.25,
                      n_estimators=100,max_depth=12,gamma=1,
                      subsample=0.8,colsample_bytree=0.5)
model.fit(X_train, y_train)
print(); print(model)
# make predictions
expected_y  = y_test
predicted_y = model.predict(X_test)
# summarize the fit of the model
print(); print('XGBClassifier: ')
print(); print(metrics.classification_report(expected_y, predicted_y, zero_division=1))
print(); print(metrics.confusion_matrix(expected_y, predicted_y))
plt.bar(range(len(model.feature_importances_)), model.feature_importances_)
plt.show()
plt.barh(range(len(model.feature_importances_)), model.feature_importances_)
plt.show()
plot_importance(model);     plt.show()
imp_fea=model.feature_importances_
print(imp_fea)
