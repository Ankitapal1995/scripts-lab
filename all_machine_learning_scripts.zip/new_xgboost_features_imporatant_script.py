#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 12:17:07 2021

@author: ankita
"""

# load libraries
from sklearn import datasets
from sklearn import metrics
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier, plot_importance
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy import loadtxt
from numpy import sort
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectFromModel
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score
from sklearn.datasets import make_classification
from xgboost import XGBRegressor
from matplotlib import pyplot
import xgboost
print(xgboost.__version__)
filename='1000_1000_iso_res_sus_iso_genes_only_for_ml.csv'
dataset = pd.read_csv(filename,sep=",",low_memory=False)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values
# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.1, random_state = 0)


# fit a ensemble.AdaBoostClassifier() model to the data
X, y = make_classification(n_samples=1000, n_features=4393, n_informative=5, n_redundant=5, random_state=1)
# define the model
# define the model
model = XGBClassifier(learning_rate = 0.01,
                      n_estimators=100,max_depth=3,gamma=1,
                      subsample=0.8,colsample_bytree=0.8)
# fit the model
model.fit(X, y)
# get importance
importance = model.feature_importances_
# summarize feature importance
for i,v in enumerate(importance):
	print('Feature: %0d, Score: %.5f' % (i,v))
# plot feature importance
pyplot.bar([x for x in range(len(importance))], importance)
pyplot.show()
print(len(importance))
np.save('important_feature.npy',importance)
#load numpy array from npy file
from numpy import load
# load array
data = load('important_feature.npy')
# print the array
#print(data)
fo=open(filename[:-3]+'important_feature.csv',"w")
for i in data:
    fo.write(str(i))
    fo.write("\n")
fo.close()
