#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 18 18:19:39 2020

@author: ankita
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from numpy import loadtxt
from numpy import sort
#from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectFromModel
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score

#Define the function and place the components.
def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='red', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()

# Importing the dataset
dataset = pd.read_csv('160_160_kanamycin_res_sus_14286_mut_profile_for_ml.csv',sep=',',low_memory=False)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
X_train = X


labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)
y_train = y
'''# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = test_size, random_state = 0)'''
#fitting XGBoost to the Training set and Test set
#from xgboost import XGBClassifier
#classifier = XGBClassifier()
#model=classifier.fit(X_train,y_train)
#early stopping prevent XGBoost to overfit
#classifier = XGBClassifier(n_estimators=10000)
#eval_set  = [(X_train,y_train), (X_test,y_test)]
#model=classifier.fit(X_train, y_train, early_stopping_rounds=5000)

#use any algorithm to fit, that is learning the data
'''from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(max_depth=15,min_samples_leaf=1,min_samples_split=5,n_estimators=500)  
classifier.fit(X_train, y_train)'''
from xgboost import XGBClassifier
'''classifier = XGBClassifier(learning_rate = 0.1,
                      n_estimators=300,max_depth=3,gamma=1,
                      subsample=0.8,colsample_bytree=0.8)'''
classifier = XGBClassifier(random_state =1)
classifier.fit(X_train,y_train)


'''#predicting the Test set results
y_pred = classifier.predict(X_test)
predictions = [round(value) for value in y_pred]
accuracy = accuracy_score(y_test, predictions)
print("Accuracy: %.2f%%" % (accuracy * 100.0))'''


'''#making the confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)'''

'''#k-fold cross validation
from sklearn.model_selection import cross_val_score
accuracies= cross_val_score(estimator = classifier,X = X_train, y=y_train, cv =10)
accuracies.mean()
accuracies.std()'''

#plot the ROC curve
'''probs = classifier.predict_proba(X_test)  
probs = probs[:, 1]  
fper, tper, thresholds = roc_curve(y_test, probs) 
auc=metrics.auc(fper, tper)
plot_roc_curve(fper, tper)
print(auc)'''

# feature importance
#print(classifier.feature_importances_)
# plot
#plt.bar(range(len(classifier.feature_importances_)),classifier.feature_importances_)
#plt.show()
import pickle
#save the trainned model as a pickle string
pkl_filename = "pickle_"+"xgb_160_160_kanamycin_res_sus_14286_mut_profile_for_ml.csv"
with open(pkl_filename, 'wb') as file:
    pickle.dump(classifier, file)
# Load the pickled model 
with open(pkl_filename, 'rb') as file:
    pickle_model = pickle.load(file)
# Calculate the accuracy score and predict target values
#score = pickle_model.score(Xtest, Ytest)
#print("Test score: {0:.2f} %".format(100 * score))
#Ypredict = pickle_model.predict(Xtest)