#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 17:52:13 2020

@author: ankita
"""

from numpy import load
filename="xgboost_important_506_genomes_features.npy"
data =load(filename)
print(data)
fo=open("important_features"+filename+".csv","w")
for i in data:
    fo.write(str(i))
    fo.write("\n")
fo.close()