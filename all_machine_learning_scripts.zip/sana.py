#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 22 16:13:24 2020

@author: ankita
"""
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn import metrics
import matplotlib.pyplot as plt
#numpy_array = np.genfromtxt("sana_test_positive_labelling.csv", delimiter=";", skip_header=1)
data=pd.read_csv("sana_test_positive_labelling.csv" , sep=",")
y_test=data.iloc[:, -1]
probs =data.iloc[:,0]

def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='brown', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()
    
fper, tper, thresholds = roc_curve(y_test,probs) 
auc=metrics.auc(fper, tper)
plot_roc_curve(fper, tper)
print(auc)