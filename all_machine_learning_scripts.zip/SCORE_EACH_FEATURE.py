#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 22 16:46:32 2020

@author: ankita
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from numpy import loadtxt
from numpy import sort
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectFromModel
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score

#Define the function and place the components.
def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='red', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()

# Importing the dataset
dataset = pd.read_csv('/home/ankita/Desktop/working_file/dir_17_06_2020_ml/copy_final_600_inz_res+sus_bmc.csv',sep=',',low_memory=False)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

dataset=pd.read_csv('copy_final_344_inz_res+sus_test_set.csv',sep=',',low_memory=False)
X_ = dataset.iloc[:, :-1].values
y_ = dataset.iloc[:, -1].values
X_test = X_
X_train =X

# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
#labelencoder_X_1 = LabelEncoder():q!:q
#X[:, 0] = labelencoder_X_1.fit_transform(X[:, 0])
#labelencoder_X_2 = LabelEncoder()
#X[:, 2] = labelencoder_X_2.fit_transform(X[:, 2])
#ct = ColumnTransformer([("Country", OneHotEncoder(), [1])], remainder = 'passthrough')
#X = ct.fit_transform(X)
#X = X[:, 0:]
labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)
y_=labelencoder_y.fit_transform(y_)
y_train =y
y_test=y_
#fitting XGBoost to the Training set and Test set
from xgboost import XGBClassifier
classifier = XGBClassifier()
classifier.fit(X_train,y_train)

# Fit model using each importance as a threshold
thresholds = sort(classifier.feature_importances_)
for thresh in thresholds:
	# select features using threshold
	selection = SelectFromModel(classifier, threshold=thresh, prefit=True)
	select_X_train = selection.transform(X_train)
	# train model
	selection_model = XGBClassifier()
	selection_model.fit(select_X_train, y_train)
    # eval model
	select_X_test = selection.transform(X_test)
	y_pred = selection_model.predict(select_X_test)
	predictions = [round(value) for value in y_pred]
	accuracy = accuracy_score(y_test, predictions)
	print("Thresh=%.3f, n=%d, Accuracy: %.2f%%" % (thresh, select_X_train.shape[1], accuracy*100.0))
    
#making the confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
'''#print(thresholds)
import pickle
#save the trainned model as a pickle string
pkl_filename = "pickle_"+"copy_final_600_inz_res+sus_bmc.csv"
with open(pkl_filename, 'wb') as file:
    pickle.dump(model, file)
# Load the pickled model 
with open(pkl_filename, 'rb') as file:
    pickle_model = pickle.load(file)'''