import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from numpy import loadtxt
from numpy import sort
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectFromModel
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score

#Define the function and place the components.
def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='red', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()

# Importing training dataset
dataset = pd.read_csv('367_367_1775+575_noncds_cds_imp_high_frq_prof_mut_for_ml.csv',sep=',',low_memory=False)
X_train = dataset.iloc[:, :-1].values
y_train = dataset.iloc[:, -1].values

#importing test dataset
dataset1 = pd.read_csv("1000_1000_iso_res_sus_1775+575_cds_noncds_mut_prof_test_for_ml.csv",sep=',',low_memory=False)
X_test = dataset1.iloc[:, :-1].values
y_test = dataset1.iloc[:, -1].values

# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
#labelencoder_X_1 = LabelEncoder():q!:q
#X[:, 0] = labelencoder_X_1.fit_transform(X[:, 0])
#labelencoder_X_2 = LabelEncoder()
#X[:, 2] = labelencoder_X_2.fit_transform(X[:, 2])
#ct = ColumnTransformer([("Country", OneHotEncoder(), [1])], remainder = 'passthrough')
#X = ct.fit_transform(X)
#X = X[:, 0:]
labelencoder_y_train = LabelEncoder()
y_train = labelencoder_y_train.fit_transform(y_train)
 
labelencoder_y_test = LabelEncoder()
y_test = labelencoder_y_test.fit_transform(y_test)


# Splitting the dataset into the Training set and Test set
#from sklearn.model_selection import train_test_split
#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

#fitting XGBoost to the Training set and Test set

#use any algorithm to fit, that is learning the data
from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(max_depth=15,min_samples_leaf=1,n_estimators=500)  
classifier.fit(X_train, y_train)
#early stopping prevent XGBoost to overfit
#classifier = XGBClassifier(n_estimators=10000)
#eval_set  = [(X_train,y_train), (X_test,y_test)]
#classifier.fit(X_train, y_train, eval_set=eval_set,
#        eval_metric="auc", early_stopping_rounds=5000)

#making the predictions and evaluating the model

#predicting the Test set results
y_pred = classifier.predict(X_test)
predictions = [round(value) for value in y_pred]
accuracy = accuracy_score(y_test, predictions)
print("Accuracy: %.2f%%" % (accuracy * 100.0))

print(metrics.classification_report(y_test, y_pred))

'''# Fit model using each importance as a threshold
thresholds = sort(classifier.feature_importances_)
for thresh in thresholds:
	# select features using threshold
	selection = SelectFromModel(classifier, threshold=thresh, prefit=True)
	select_X_train = selection.transform(X_train)
	# train model
	selection_model = XGBClassifier()
	selection_model.fit(select_X_train, y_train)
	# eval model
	select_X_test = selection.transform(X_test)
	y_pred = selection_model.predict(select_X_test)
	predictions = [round(value) for value in y_pred]
	accuracy = accuracy_score(y_test, predictions)
	print("Thresh=%.3f, n=%d, Accuracy: %.2f%%" % (thresh, select_X_train.shape[1], accuracy*100.0))'''

#making the confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)

#k-fold cross validation
#from sklearn.model_selection import cross_val_score
#accuracies= cross_val_score(estimator = classifier,X = X_train, y=y_train, cv =10)
#accuracies.mean()
#accuracies.std()

#plot the ROC curve
probs = classifier.predict_proba(X_test)  
probs = probs[:, 1]  
fper, tper, thresholds = roc_curve(y_test, probs) 
auc=metrics.auc(fper, tper)
plot_roc_curve(fper, tper)
print(auc)

'''# feature importance
imp_fea=classifier.feature_importances_
print(classifier.feature_importances_)
# plot
plt.bar(range(len(classifier.feature_importances_)),classifier.feature_importances_)
plt.show()'''