#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 14:22:20 2020

@author: ankita
"""
#importing all libraries
import numpy as np  
import pandas as pd  
import matplotlib.pyplot as plt  
#import seaborn as sns  
from sklearn.datasets import make_classification  
#from sklearn.neighbors import KNeighborsClassifier  
from sklearn.ensemble import RandomForestClassifier  
from sklearn.model_selection import train_test_split  
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score
#from sklearn.feature_selection import SelectFromModel
#Define the function and place the components.
def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='green', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()
# Importing the dataset
dataset = pd.read_csv('1000_1000_noncds_1177_imp_mut_prof_for_ml.csv',sep=",",low_memory=False)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

# Encoding categorical data
labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)


'''from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)'''
#use the classification and model selection to scrutinize and random division of data
#data_X, cls_lab = make_classification(n_samples=1100, n_classes=2, weights=[1,1], random_state=1)  
# Splitting the dataset into the Training set and Test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2,stratify=y,random_state = 1)
#use any algorithm to fit, that is learning the data
model = RandomForestClassifier(max_depth=15,min_samples_leaf=1,min_samples_split=5,n_estimators=500)  
model.fit(X_train, y_train)
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
#predicting the Test set results
y_pred = model.predict(X_test)
predictions = [round(value) for value in y_pred]
print(predictions)
print(recall_score(y_test, y_pred, average=None, zero_division=1))
print(precision_score(y_test, y_pred, average=None, zero_division=1))
print(f1_score(y_test, y_pred, average=None, zero_division=1))

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy: %.2f%%" % (accuracy * 100.0))

print(metrics.classification_report(y_test, y_pred, zero_division=1))
#k-fold cross validation
from sklearn.model_selection import cross_val_score
accuracies= cross_val_score(estimator = model,X = X_train, y=y_train, cv =10)
accuracies.mean()
accuracies.std()

#making the confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
print (cm)

#plot the ROC curve
probs = model.predict_proba(X_test)  
probs = probs[:, 1]  
fper, tper, thresholds = roc_curve(y_test, probs) 
auc=metrics.auc(fper, tper)
plot_roc_curve(fper, tper)
print(auc)