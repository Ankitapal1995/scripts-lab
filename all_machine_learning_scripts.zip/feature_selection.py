filename2="list_xgboost_imp_for_906_res+sus_sc_rt.csv"
filename1="cp_final_906_res+sus_model_for_classification.csv.csv"

f2=open(filename2,"r")
feat_name=[]
for line in f2:
    line=line.strip("\n")
    feat_name.append(line)
#print(feat_name)
import pandas as pd
import numpy as np
data=pd.read_csv(filename1,sep=",",low_memory=False)
#data1=data[np.intersect1d(data.columns, feat_name)]
data1=data.reindex(columns=feat_name)
#print(data1)
#data1.to_hdf('final_510_res+sus_kmer_matrix_remv_redun.csv', '/data', complib='zlib', complevel=9)
data1.to_csv(filename1+'.csv', encoding = "utf-8")