import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from numpy import savetxt
from sys import argv
script,filename=argv
dataset = pd.read_csv(filename,sep=',',low_memory=False)
data=dataset.T
sum_row=data.sum(axis=1) #frequency of features in all the genomes

#print(len(sum_row))
data["sum"]=sum_row
feat_score = 0.0
#print(len(sum_row))
savetxt('feature_sum_of_all_genome.csv', sum_row, delimiter=',')

fo=open('feature_sum_of_all_genome.csv',"r")
score=[]
for line in fo:
    line=line.strip("\n")
    score.append(line)
f1=open(filename,"r")
lines=[]
for line in f1:
    line=line.strip("\n")
    lines.append(line)
#####
mut_index=lines[0].split(",")
#print(mut_index)

mut_score=dict(zip(mut_index,score))
#print(mut_score)
for i in mut_score:
    if float(mut_score[i])>0:
        print(i)
