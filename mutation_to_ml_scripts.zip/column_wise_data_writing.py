from sys import argv
script,filename2,r=argv
import zipfile
zip1=zipfile.ZipFile(filename2)
list_f=zip1.namelist()
#print(list_f)
def col_extract(txt):
    mg_ls=[]
    f=open(txt,"r")
    for line in f:
        line=line.strip("\n")
        l=line.split(";")[-1]
        m=str(l)
        mg_ls.append(m)
#    print(mg_ls)
    return mg_ls
fo=open(r+"_set_final_output.csv","w")
for i in range(len(list_f)):
    list_f[i]=col_extract(list_f[i])
for i in range(len(list_f)):
    for j in list_f[i]:
        fo.write(str(j))
        fo.write(",")
    fo.write(r)
    fo.write("\n")
fo.close()

