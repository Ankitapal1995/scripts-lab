from sys import argv
script,filename1,filename2=argv
f1=open(filename1,"r")
n=f1.readlines()
sl=[]
mut=[]
dict1={}
for line in n:
    line=line.strip("\n")
    l=line.split(";")[0]
    j=line.split(";")[1]
    sl.append(l)
    mut.append(j)
dict1=dict(zip(sl,mut))
print(dict1)
print(len(dict1))
f2=open(filename2,"r")
h=f2.readlines()
sl_nw=[]
for line in h:
    line=line.strip("\n")
    sl_nw.append(line)
#print(sl_nw)
dict2={}
for i in sl_nw:
    dict2[i]=dict1[i]
print(dict2)
print(len(dict2))
fw=open(filename1+"_with_freq.csv","w")
for i in dict2:
    fw.write(dict2[i])
    fw.write("\n")
fw.close()

