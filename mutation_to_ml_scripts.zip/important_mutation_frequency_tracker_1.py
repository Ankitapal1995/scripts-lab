from sys import argv
script,filename1,filename2=argv
f1=open(filename1,"r")
n=f1.readlines()
freq=[]
mut=[]
dict1={}
for line in n:
    line=line.strip("\n")
    l=line.split(";")[0]
    j=line.split(";")[1]
    freq.append(l)
    mut.append(j)
dict1=dict(zip(mut,freq))
#print(dict1)
'''print(f'before removing less freq mutations: {len(dict1)}')
dict2={}
for i in dict1:
    if dict1[i]>int(k):
        dict2[i]=dict1[i]
    else:
        pass
print(f'after removing less freq mutations: {len(dict2)}')'''

f2=open(filename2,"r")
h=f2.readlines()
freq_nw=[]
for line in h:
    line=line.strip("\n")
    freq_nw.append(line)
#print(freq_nw)
dict2={}
for i in freq_nw:
    dict2[i]=dict1[i]
print(dict2)
print(len(dict2))
fw=open(filename1+"_with_filtered_mut_freq.csv","w")
for i in dict2:
    fw.write(i)
    fw.write(";")
    fw.write(str(dict2[i]))
    fw.write("\n")
fw.close()

