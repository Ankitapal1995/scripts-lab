from sys import argv
scripts,filename=argv
fo=open(filename,"r")
n=fo.readlines()
feat=[]
for i in n:
    i=i.strip("\n")
    feat.append(i)
#print(len(feat))
fo=open(filename+".csv","w")
for i in range(len(feat)):
    fo.write("f"+str(i))
    fo.write(",")
fo.write("label")
fo.write("\n")
