#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 18 15:46:28 2020

@author: ankita
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from numpy import loadtxt
from numpy import sort
#from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectFromModel
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from sklearn.metrics import roc_curve 
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score
import pickle
from sklearn.model_selection import KFold
from sklearn.metrics import confusion_matrix
with open("pickle_cp_final_906_res+sus_model_for_classification.csv", 'rb') as f:
    model= pickle.load(f)

def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='brown', label='ROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()
        
'''f=open("only_285_imp_features.csv", "r")
feat_name=[]
for line in f:
    line=line.strip("\n")
    feat_name.append(line)

#print(data1)
#file_name=filename1.rsplit(".",1)[0]
#data1.to_csv(file_name+".csv",encoding='utf-8')'''


# Importing the dataset
filename="mtb_h37rv.csv"
'''data = pd.read_csv(filename,sep=',',low_memory=False)
s_dataset=data.reindex(columns=feat_name)
file_name=filename.rsplit(".",1)[0]+".csv"
s_dataset.to_csv(file_name,encoding='utf-8')'''
dataset=pd.read_csv(filename,sep=',',low_memory=False)
X_ = dataset.iloc[:, :-1].values
y_ = dataset.iloc[:, -1].values
X_test = X_

# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer

labelencoder_y = LabelEncoder()
y_ = labelencoder_y.fit_transform(y_)
y_test=y_

#predicting the Test set results
#y_pred = xgboost_model.predict(X_test)
#y_pred = model.predict(X_test)
'''y_pred = model.predict(X_test)
predictions = [round(value) for value in y_pred]
accuracy = accuracy_score(y_test, predictions)
print("Accuracy: %.2f%%" % (accuracy * 100.0))'''

'''kfold = KFold(n_splits=3, random_state=42) 
scores = cross_val_score(model, x_train, y_train, cv=kfold, scoring='roc_auc')
print("Mean AUC Score - Random Forest: ", scores.mean())'''





'''y_pred = (model.predict_proba(X_test))
#print(y_pred)
labelencoder_y = LabelEncoder()
y_pred = labelencoder_y.fit_transform(y_pred)
predictions = [round(value) for value in y_pred]
#predict_mine = np.where(predict_probabilities > 0.996036, 1, 0)
print(predictions)
print(len(predictions))
accuracy = accuracy_score(y_test, predictions)
print("Accuracy: %.2f%%" % (accuracy * 100.0))'''
cm = confusion_matrix(y_test, predictions)
print(cm)
total=sum(sum(cm))
print(total)
accuracy1=(cm[0,0]+cm[1,1])/total
print(f"accuracy1: {accuracy1}")
sensitivity = cm[0,0]/(cm[0,0]+cm[0,1])
print(f"sensitivity: {sensitivity}")
specificity = cm[1,1]/(cm[1,0]+cm[1,1])
print(f"specificity:{specificity}")
#plot the ROC curve
#probs = xgboost_model.predict_proba(X_test)
probs = model.predict_proba(X_test)  
probs = probs[:, 1]  
fper, tper, thresholds = roc_curve(y_test,probs) 
auc=metrics.auc(fper, tper)
plot_roc_curve(fper, tper)
print(f"auc before selecting cutoff : {auc}")

#deciding a thresold to classify
def adjusted_classes(probs, y_test):
    return [1 if y >= t else 0 for y in probs]
t=0.45234731801230965
y_pred_adj = adjusted_classes(probs, t)
print(pd.DataFrame(confusion_matrix(y_test, y_pred_adj),
                       columns=['pred_neg', 'pred_pos'], 
                       index=['neg', 'pos']))
cm1=confusion_matrix(y_test, y_pred_adj)
accuracy2=(cm1[0,0]+cm1[1,1])/total
print(f"accuracy2: {accuracy2}")
sensitivity1 = cm1[0,0]/(cm1[0,0]+cm1[0,1])
print(f"sensitivity: {sensitivity1}")
specificity1 = cm1[1,1]/(cm1[1,0]+cm1[1,1])
print(f"specificity:{specificity1}")
fper1, tper1, thresholds1 = roc_curve(y_test,y_pred_adj)
plot_roc_curve(fper1,tper1)
auc =metrics.auc(fper1,tper1)
print(f"auc after selecting cutoff {auc}")