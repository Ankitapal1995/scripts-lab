#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  7 15:49:28 2020

@author: ankita
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.cm import rainbow
%matplotlib inline
import warnings
warnings.filterwarnings('ignore')


dataset = pd.read_csv('/home/ankita/Desktop/working_file/dir_17_06_2020_ml/temp_dir/exclu_low_abun15_mer_510_res+sus.csv',sep=',',low_memory=False)
#X = dataset.iloc[:, :-1].values
#y = dataset.iloc[:, -1].values

rcParams['figure.figsize'] = 20, 14
plt.matshow(dataset.corr())
plt.yticks(np.arange(dataset.shape[1]), dataset.columns)
plt.xticks(np.arange(dataset.shape[1]), dataset.columns)
plt.colorbar()