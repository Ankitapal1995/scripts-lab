#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 14 18:32:03 2020

@author: ankita
"""
from sklearn.ensemble import RandomForestClassifier
import numpy as np, matplotlib.pyplot as plt,  pandas as pd
from sklearn.model_selection import cross_val_score,cross_val_predict,  KFold,  LeaveOneOut, StratifiedKFold
from sklearn.metrics import roc_curve, auc
from sklearn import datasets
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score

dataset = pd.read_csv('cp_final_906_res+sus_model_for_classification.csv',sep=',',low_memory=False)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values
#X_, y_ = X[y != 2], y[y != 2]
# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer

labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)
#model loading
clf = RandomForestClassifier(random_state=1)
#clf = SVC(kernel='linear', class_weight='balanced', probability=True, random_state=0)
kf = LeaveOneOut()

scores = cross_val_score(clf, X, y, scoring='accuracy', cv=kf, n_jobs=-1)
print(scores)
y_true, y_pred = list(), list()
for train_ix, test_ix in kf.split(X , y):
	# split data
	X_train, X_test = X[train_ix, :], X[test_ix, :]
	y_train, y_test = y[train_ix], y[test_ix]
	# fit model
	model = RandomForestClassifier(random_state=1)
	model1=model.fit(X_train, y_train)
	# evaluate model
	yhat = model1.predict(X_test)
	# store
	y_true.append(y_test[0])
	y_pred.append(yhat[0])
print(y_pred)
# calculate accuracy
cm = confusion_matrix(y_true, y_pred)
print(cm)
acc = accuracy_score(y_true, y_pred)
print('Accuracy: %.3f' % acc)

all_y = []
all_probs=[]
for train, test in kf.split(X, y):
    all_y.append(y[test])
    all_probs.append(clf.fit(X[train], y[train]).predict_proba(X[test])[:,1])
all_y = np.array(all_y)
all_probs = np.array(all_probs)

fpr, tpr, thresholds = roc_curve(all_y,all_probs)
roc_auc = auc(fpr, tpr)
def plot_roc_curve(fper, tper):  
    plt.plot(fper, tper, color='red', label='LOOROC')
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend()
    plt.show()
plot_roc_curve(fpr, tpr)
auc=metrics.auc(fpr, tpr)
print(auc)