#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug  8 21:09:50 2020

@author: ankita
"""
import pandas as pd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
# Importing the dataset
dataset = pd.read_csv('list_110_important_features_xgboost_906_genomes',sep=",",low_memory=False)

y = dataset.iloc[:, -1]
for i in range(1,50)
X_1= dataset.iloc[:,1]
X_2=dataset.iloc[:,2]
X_3=dataset.iloc[:,3]
f_1=X_1.corr(y)
f_2=X_1.corr(y)
f_3=X_3.corr(y)
# Encoding categorical data
#labelencoder_y = LabelEncoder()
#y = labelencoder_y.fit_transform(y)
    
