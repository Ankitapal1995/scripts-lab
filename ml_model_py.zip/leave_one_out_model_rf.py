#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 14 12:54:00 2020

@author: ankita
"""

# loocv to manually evaluate the performance of a random forest classifier
from sklearn.ensemble import RandomForestClassifier
import numpy as np, matplotlib.pyplot as plt,  pandas as pd
from sklearn.model_selection import cross_val_score,cross_val_predict,  KFold,  LeaveOneOut, StratifiedKFold
from sklearn.metrics import roc_curve, auc
from sklearn import datasets
dataset = pd.read_csv('cp_final_906_res+sus_model_for_classification.csv',sep=',',low_memory=False)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values
# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer

labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)


# create dataset
#X, y = make_blobs(n_samples=100, random_state=1)
# create loocv procedure
cv = LeaveOneOut()
# create model
model = RandomForestClassifier(random_state=1)
# evaluate model
scores = cross_val_score(model, X, y, scoring='accuracy', cv=cv, n_jobs=-1)
# report performance
print(scores)
#print('Accuracy: %.3f (%.3f)' % (mean(scores), std(scores)))
# enumerate splits
'''y_true, y_pred, prob= list(), list(), list()
for train_ix, test_ix in cv.split(X , y):
	# split data
	X_train, X_test = X[train_ix, :], X[test_ix, :]
	y_train, y_test = y[train_ix], y[test_ix]
	# fit model
	model = RandomForestClassifier(random_state=1)
	model1=model.fit(X_train, y_train)
	# evaluate model
	yhat = model1.predict(X_test)
	# store
	y_true.append(y_test[0])
	y_pred.append(yhat[0])
print(y_pred)
# calculate accuracy
acc = accuracy_score(y_true, y_pred)
print('Accuracy: %.3f' % acc)'''
#plot the ROC curve
# enumerate splits
all_y=[]
all_probs=[]
for train, test in cv.split(X, y):
    print(y[test])
	# split data
	all_y.append(y[test])
    #all_probs.append(model.fit(X[train], y[train]).predict_proba(X[test])[:,1])
	# fit model
	#all_y = np.array(all_y)
    #all_probs = np.array(all_probs)
fpr, tpr, thresholds = roc_curve(all_y,all_probs)
roc_auc = auc(fpr, tpr)
plt.figure(1, figsize=(12,6))"
plt.plot(fpr, tpr, lw=2, alpha=0.5, label='LOOCV ROC (AUC = %0.2f)' % (roc_auc))
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='k', label='Chance level', alpha=.8)
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.grid()
plt.show()