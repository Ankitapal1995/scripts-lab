#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 15:10:06 2020

@author: ankita
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso, LogisticRegression
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import StandardScaler

dataset = pd.read_csv('final_226+226_res+sus_for_ml_sklearn.csv.csv',sep=',',low_memory=False)
X = dataset.iloc[:,1 :-1].values
y = dataset.iloc[:, -1].values
# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer

labelencoder_y = LabelEncoder()
y= labelencoder_y.fit_transform(y)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)


# linear models benefit from feature scaling
#scaler=StandardScaler()
#scaler.fit(X_train)

sel_ = SelectFromModel(LogisticRegression(C=1, penalty='l1',solver='liblinear'))
sel_.fit(X_train, y_train)
#print(sel_.fit(X_train,y_train))
mm=sel_.get_support()
print(mm)
for i in mm:
    print(i)
'''selected_feat = X_train.columns[sel_.get_support()]
print('total features: {}'.format((X_train.shape[1])))
print('selected features: {}'.format(len(selected_feat)))
print('features with coefficients shrank to zero: {}'.format(
      np.sum(sel_.estimator_.coef_ == 0)))


#removed_feats = X_train.columns[(sel_.estimator_.coef_ == 0).ravel().tolist()]
#removed_feats

#X_train_selected = sel_.transform(X_train)
#X_test_selected = sel_.transform(X_test)
#X_train_selected.shape, X_test_selected.shape'''
#,solver='liblinear'