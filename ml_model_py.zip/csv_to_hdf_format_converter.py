import pandas as pd
df = pd.DataFrame()
df = pd.read_hdf("1000_res+sus_iso_kmer_matrix_model.h5",sep=',',low_memory=False,dtype="int8")
df.info()