from sys import argv
script,filename=argv
import zipfile
zip=zipfile.ZipFile(filename)
list_f=zip.namelist()
mg_ls=[]
for i in list_f:
    f=open(i,"r")
    for line in f:
        line=line.strip("\n")
        l=line.split()[0]
        mg_ls.append(l)
#print(mg_ls)
for j in mg_ls:
    print(j)
